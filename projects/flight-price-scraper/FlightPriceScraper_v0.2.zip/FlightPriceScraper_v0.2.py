########   Flight Price Scraper  ########
#
# A Selenium based flight price scraping tool
#
# 2019/05/17
# v0.2, updated URL generator and parsing scheme to match the new Google
#     Flights website
#
# Denedencies:
#   Firefox: Web browser, https://www.mozilla.org/en-US/firefox/new/
#   Geckodriver: Firefox webdriver, https://github.com/mozilla/geckodriver/releases
#       - For Linux, extract to /usr/bin
#       - For OSX, extract to /usr/local/bin/
#   Selenium: Browser automation tool, http://www.seleniumhq.org/
#   Beautiful Soup 4: Library for scraping HTML and XML, https://www.crummy.com/software/BeautifulSoup/
#   lxml: Library for parsing HTML and XML, http://lxml.de/
#
#########################################

# import selenium to load page in Firefox
from selenium import webdriver
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
# import time to add a delay for the page to fully load
import time
# import BeautifulSoup to parse what we download
from bs4 import BeautifulSoup
# import re to process source code with regular expressions
import re
# import smtplib to allow us to email
import smtplib
import csv
import datetime

# flight price currency (USD,EUR,GBP,etc.) 
currency = "USD"

# price threshold for deals
threshold = 500

# airline codes from Google Flights search URL, none=ALL
airlines_searched = ""

# single or comma separated list of airport codes, no spaces
airports_from = "DFW,IAH"
airports_to = "JNB,CPT,NBO,DAR,JRO"

# min and max departure dates as datetime objects
depart_date_min = datetime.datetime.strptime("2019-07-11","%Y-%m-%d")
depart_date_max = datetime.datetime.strptime("2020-05-11","%Y-%m-%d")

# min and max trip lengths in days
trip_len_min = 14
trip_len_max = 28

# setup email addresses and Gmail account password
email_from = "example_gmail_address@gmail.com"
email_from_pw = "example_gmail_password"
email_to = ["example_recipient@email.com"]

def scrape_google_flights(browser, airports_from, airports_to, depart_date, return_date):
	
	# populate URL with departure and return dates
	url = "https://www.google.com/flights/#flt="+airports_from+ \
		  "."+airports_to+"."+depart_date.strftime("%Y-%m-%d")+ \
		  "*"+airports_to+"."+airports_from+"." \
		  +return_date.strftime("%Y-%m-%d")+";c:"+currency+";e:1" \
		  +";a:"+airlines_searched+"*"+airlines_searched+";sd:1;t:f"

	# keep trying to load page and parse data forever
	while True:
		try:
			# open browser and navigate to URL
			browser.get(url)

			# delete all cookies before each search
			browser.delete_all_cookies()

			# refresh the page
			browser.refresh()

			# wait 10 seconds for page to load before grabbing source code
			time.sleep(10)
			html = browser.page_source
			soup = BeautifulSoup(html, "lxml")
			soup.prettify()

			# find all elements in price class inside HTML soup
			reduced_soup = soup.findAll("div", {"class" : "gws-flights-results__price"})

			# record Gogole's "Best" flight price and strip special characters
			price = int(re.sub("[^0-9]", "", reduced_soup[0].getText()))
			

			# record airports
			reduced_soup = soup.findAll("div", {"class" : "gws-flights-results__airports"})
			airport_from = reduced_soup[0].findAll("span")[0].getText()
			airport_to = reduced_soup[0].findAll("span")[1].getText()

			# exit while loop if price scrape is successful
			break
		# throw error and try again if the page can't be parsed
		# (e.g. network error, server error)
		except Exception:
			pass

		print("ERROR: Can't get price data. Refreshing page...")

		# wait to avoid constant refreshing if there's an error
		time.sleep(5)

	# open FlightPrices.csv to append data
	with open("GFlights_"+depart_date_min.strftime("%m-%d")+"_"+
	depart_date_max.strftime("%m-%d")+"_"+airports_from.replace(
	",","-")+"_"+airports_to.replace(",","-")+".csv", "a") as csvfile:
		# CSV data is tab delimited, quotechar "|" around data with tabs
		writer = csv.writer(csvfile, delimiter="\t", quotechar="|",
				 quoting=csv.QUOTE_MINIMAL)
		writer.writerow(["{0:.2f}".format(price),
			depart_date.strftime("%Y-%m-%d"),
			return_date.strftime("%Y-%m-%d"),
			airport_from+" - "+airport_to,url])
	
	print("------------------------")
	print(depart_date.strftime("%Y-%m-%d")+" to "+
		return_date.strftime("%Y-%m-%d"))
	print("{0:.2f}".format(price)+" "+currency+", "+
		airport_from+"-"+airport_to)

	# send an email if the price is below the defined threshold
	if price <= threshold:
		print("Found a deal! Sending email...")
		send_email(depart_date, return_date, airport_to, airport_from, price, url)

def send_email(depart_date, return_date, airport_to, airport_from, price, url):
	# setup the email server
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.starttls()

	# add Gmail account login name and password
	server.login(email_from, email_from_pw)

	# create message with the format: [Subject] "\n\n" [Body]
	message = "Subject: "+airport_from+" to "+airport_to+ \
		" for "+str(price)+" "+currency+ \
		"\n\nFlight deal from "+airport_from+" to "+airport_to+ \
		"!\n\nDeparts: "+depart_date.strftime("%Y-%m-%d")+ \
		"\nReturns: "+return_date.strftime("%Y-%m-%d")+ \
		"\nPrice: "+str(price)+ " "+currency+ \
		"\n\n"+url

	# send the email and disconnect from server
	server.sendmail(email_from, email_to, message)
	server.quit()

	# quit python - our work here is done
	quit()

def main():

	# tell selenium to use Firefox
	browser = webdriver.Firefox()

	# run the program indefinitely
	while 1:

		# initialize departure date and trip length
		depart_date = depart_date_min
		trip_len = trip_len_min

		# iterate through all dates and trip lengths within the specified range
		while depart_date <= depart_date_max:
			while trip_len <= trip_len_max:
				trip_len = trip_len + 1
				
				# add trip length to departure date to find return date
				delta = datetime.timedelta(days=trip_len)
				return_date = depart_date + delta

				scrape_google_flights(browser, airports_from, airports_to, depart_date, return_date)

			trip_len = trip_len_min
			depart_date = depart_date + datetime.timedelta(days=1)

main()
