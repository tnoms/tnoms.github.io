-----------------------------------------
           Flight Price Scraper  
-----------------------------------------

A Selenium based flight price scraping tool

Denedencies -

  Firefox, web browser
  Geckodriver, webdriver
  Selenium, Browser automation tool
  Beautiful Soup 4, web scraping library
  lxml, parser for HTML and XML

Installation -

  Download and install the most recent version of Firefox from:
    https://www.mozilla.org/en-US/firefox/new/

  Download the most recent Geckodriver from, or use one of the included drivers:
    https://github.com/mozilla/geckodriver/releases

  Extract Geckodriver to the appropriate directory:
    - For Linux, extract to /usr/bin
    - For OSX, extract to /usr/local/bin/
    - For Windows, extract to your Python parent folder, e.g. C:\Python34

  Use the Python package installer to install everything else:
    $ pip install selenium
    $ pip install bs4
    $ pip install lxml

Configuration -
  
  All of the important variables to configure the scraper are found in the first few lines of code before any functions are defined:

    currency = Currency code used for flight price search results, e.g. USD, EUR, GBP, etc.

    threshold = Price threshold to send an email alert for a deal.

    airlines_searched = Comma separated list of airline codes to search specific airlines. All airlines will be searched if left blank.

    airports_from = Comma separated list of origin airport codes, no spaces.
    
    airports_to = Comma separated list of destination airport codes, no spaces.

    depart_date_min = Earliest departure date to search. Only modify the date between the quotes and leave the formatting.

    depart_date_max = Latest departure date to search. Only modify the date between the quotes and leave the formatting.

    trip_len_min = Minimum trip length in days. Return date will be the departure date + the trip length.

    trip_len_min = Maximum trip length in days. Return date will be the departure date + the trip length.

    email_from = Gmail account used to send price alert emails.

    email_from_pw = Password for price alert Gmail account.

    email_to = Recipient of price alert emails. Can be an array with multiple email addresses.
    