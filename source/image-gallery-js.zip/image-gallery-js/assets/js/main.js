/*
	Strata by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
*/

(function($) {

	var $window = $(window);

		// Lightbox gallery.
			$window.on('load', function() {

				$('#gallery').poptrox({
					caption: function($a) { return $("img", $a).first().attr("alt"); },
					overlayColor: '#2c2c2c',
					overlayOpacity: 0.85,
					popupCloserText: '',
					popupLoaderText: '',
					selector: 'a.gallery-link',
					usePopupCaption: true,
					usePopupDefaultStyling: false,
					usePopupEasyClose: false,
					usePopupNav: true,
					useBodyOverflow: false
				});

			});

})(jQuery);